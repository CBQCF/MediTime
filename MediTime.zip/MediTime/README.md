# MediTime
UQAC Project (Informatique Mobile) | Android application to keep track of your medications 
